java -jar bin/ChironSetup-2.0.jar -d SC.xml
java -jar bin/ChironSetup-2.0.jar -i SC.xml

